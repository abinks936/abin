package project6;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class emps {
	Connection cn;
	Statement smt;
	ResultSet rs=null;
	String name,status,city;
	int age,id;

	public void insert_details()
	{
	
		try
		{
	
			
			Class.forName("oracle.jdbc.driver.OracleDriver");			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "gameloft");
			smt=cn.createStatement();
			
			
			Scanner s=new Scanner(System.in);
			System.out.println("enter the id");
			id=s.nextInt();
			s.nextLine();
			
			System.out.println("enter the name");
			name=s.nextLine();
			
			System.out.println("enter the age");
			age=s.nextInt();
			s.nextLine();
			
			
			System.out.println("enter  the city name");
			city=s.nextLine();
			s.nextLine();
			
			String insert="insert into student1 values('"+id+"','"+name+"','"+age+"','"+city+"')";
			smt.executeUpdate(insert);
			System.out.println("!.............data stored...............!");
	
			smt.close();
			cn.close();
			
		}
		catch(Exception e)
		{
			System.out.println("hi"+e);
		}	
	}

	public static void main(String[] args) {
		emps p=new emps();
		
		p.insert_details();


	}

}


public class stude {

}

package pro9;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("/data")
public class pro {
	
	@GET
	@Path("/add/{name}/{age}")
	public String get(@PathParam("name") String name,@PathParam("age") int age)
	{
		Connection cn;
		Statement smt;
		
		try
		{
	
			
			Class.forName("oracle.jdbc.driver.OracleDriver");			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "gameloft");
			smt=cn.createStatement();
			
			
			String insert="insert into pro9 values('"+name+"','"+age+"')";
			smt.executeUpdate(insert);
			System.out.println("data stored...............");
			smt.close();
			cn.close();
			
		}
		catch(Exception e)
		{
			System.out.println("hi"+e);
		}
		return "data added";

	}
	
	@GET
	@Path("/delete/{age}")
	public String get(@PathParam("age") int age)
	{
		Connection cn;
		Statement smt;
		
		try
		{
	
			
			Class.forName("oracle.jdbc.driver.OracleDriver");			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "gameloft");
			smt=cn.createStatement();
			
			
			String del="delete from pro9 where age='"+age+"'";
			smt.executeUpdate(del);
			System.out.println("data stored...............");
			smt.close();
			cn.close();
			
		}
		catch(Exception e)
		{
			System.out.println("hi"+e);
		}
		return "data deleted";

	}
	@GET
	@Path("/update/{name}/{age}")
	public String getupdate(@PathParam("name") String name,@PathParam("age") int age)
	{
		Connection cn;
		Statement smt;
		
		try
		{
	
			
			Class.forName("oracle.jdbc.driver.OracleDriver");			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "gameloft");
			smt=cn.createStatement();
			
			
			String insert="update pro9 set age='"+age+"' where name='"+name+"'";
			smt.executeUpdate(insert);
			System.out.println("data stored...............");
			smt.close();
			cn.close();
			
		}
		catch(Exception e)
		{
			System.out.println("hi"+e);
		}
		return "data updated";

	}
}
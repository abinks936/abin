package project10;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

public class pro {

	public static void main(String[] args) {
		
		ArrayList<student> al=new ArrayList();
		
		student s1=new student("mustafa",32,"hubballi");

		student s2=new student("abhin",12,"kerala");

		student s3=new student("rakshith",82,"bangalore");
		
		al.add(s1);
		
		al.add(s2);
		
		al.add(s3);
		
		for(student s:al)
		{
			System.out.println(s.name+" "+s.age+" "+s.city);
		}
		
		al.remove(s2);
		for(student s:al)
		{
			System.out.println(s.name+" "+s.age+" "+s.city);
		}
	              
	}
	

}
